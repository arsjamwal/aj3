package com.cg.bankapp.persistance;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.cg.bankapp.bean.Account;
import com.cg.bankapp.bean.Transaction;
import com.cg.bankapp.exception.BankException;
import com.cg.bankapp.util.ConnectionFactory;

public class AccountRepoImpl implements IAccountRepo {

	Connection con = null;
	PreparedStatement ps = null;

	@Override
	public long addAccount(Account a) throws BankException {

		try {
			con = ConnectionFactory.getSigtonObj().getConnection();
		} catch (BankException e) {
			// TODO Auto-generated catch block
			throw new BankException("connection issues!");
		}
		long accNum = 0;
		try {
			ps = con.prepareStatement(QueryMapping.INSERT_QUERY);
			// ps.setString(1, "");
			ps.setString(1, a.getAccHolder());
			ps.setString(2, a.getAddress());
			ps.setLong(3, a.getMobNum());
			ps.setDouble(4, a.getBalance());
			ps.setString(5, a.getEmail());

			ps.executeUpdate();

			ps = con.prepareStatement(QueryMapping.SEQ_CURR_VAL);
			ResultSet rs = ps.executeQuery();
			rs.next();
			accNum = rs.getLong(1);
			deposit(accNum, 500);
		} catch (Exception e) {
			throw new BankException("coudn't run query. " + e.getMessage());
		} finally {
			try {
				if (con != null)
					con.close();
				if (ps != null)
					ps.close();
			} catch (Exception e) {
				throw new BankException("problem in connection closing!!!!"+e.getMessage());
			}
		}

		return accNum;
	}

	@Override
	public double showBalance(long accNum) throws BankException {
		// TODO Auto-generated method stub
		// System.out.println(bank.get(accNum).getBalance());
		ResultSet rs = null;
		double balance;
		try {
			con = ConnectionFactory.getSigtonObj().getConnection();
		} catch (BankException e) {
			// TODO Auto-generated catch block
			throw new BankException("connection couldn't be established!!!");
		}
		try {
			ps = con.prepareStatement(QueryMapping.SELECT_BALENCE_QUERY);
			ps.setLong(1, accNum);
			rs = ps.executeQuery();
			if(rs.next())
				balance = rs.getDouble(1);
			else {
				if (con != null)
					con.close();
				if (ps != null)
					ps.close();
				throw new BankException("account number is not present!!!!");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new BankException("couldn't execute query!!!");
		} finally {
			try {
				if (con != null)
					con.close();
				if (ps != null)
					ps.close();
				if (rs != null)
					rs.close();
			} catch (Exception e) {
				throw new BankException("problem in connection closing!!!!");
			}
		}
		return balance;
	}

	@Override
	public boolean deposit(long accNum, double ammount) throws BankException {
		ResultSet rs = null;
		double balance = 0;
		try {
			con = ConnectionFactory.getSigtonObj().getConnection();
		} catch (BankException e) {
			// TODO Auto-generated catch block
			throw new BankException("connection couldn't be established!!!");
		}
		try {
			ps = con.prepareStatement(QueryMapping.SELECT_BALENCE_QUERY);
			ps.setLong(1, accNum);
			rs = ps.executeQuery();
			ps = con.prepareStatement(QueryMapping.UPDATE_QUERY);
			if (rs.next())
				balance = rs.getDouble(1) + ammount;
			else {
				con.close();
				ps.close();
				rs.close();
				throw new BankException("account number is not present!!!!");
			}
			ps.setDouble(1, balance);
			ps.setLong(2, accNum);
			ps.executeUpdate();
			System.out.println("------------------------------------------------");
			System.out.println("Done!!!!");
			System.out.println("------------------------------------------------");
		} catch (Exception e) {
			throw new BankException("couldn't execute query!!!");
		} finally {
			try {
				if (con != null)
					con.close();
				if (ps != null)
					ps.close();
				if (rs != null)
					rs.close();
			} catch (Exception e) {
				throw new BankException("problem in connection closing!!!!");
			}
		}

		putTransaction(ammount, accNum, "Credited", balance);
		return true;
	}

	@Override
	public boolean withdraw(long accNum, double ammount) throws BankException {
		ResultSet rs = null;
		try {
			con = ConnectionFactory.getSigtonObj().getConnection();
		} catch (BankException e) {
			// TODO Auto-generated catch block
			throw new BankException("connection couldn't be stablished!!!");
		}
		try {
			ps = con.prepareStatement(QueryMapping.SELECT_BALENCE_QUERY);
			ps.setLong(1, accNum);
			rs = ps.executeQuery();
			ps = con.prepareStatement(QueryMapping.UPDATE_QUERY);
			double balance;
			if (rs.next())
				balance = rs.getDouble(1) - ammount;
			else {
				con.close();
				ps.close();
				rs.close();
				throw new BankException("account number is not present!!!!");
			}
			ps.setDouble(1, balance);
			ps.setLong(2, accNum);
			ps.executeUpdate();
			System.out.println("------------------------------------------------");
			System.out.println("Done!!!!");
			System.out.println("------------------------------------------------");
			putTransaction(ammount, accNum, "Debited", balance);
			return true;
		} catch (Exception e) {
			throw new BankException("couldn't execute query!!! "+e.getMessage());
		} finally {
			try {
				if (con != null)
					con.close();
				if (ps != null)
					ps.close();
				if (rs != null)
					rs.close();
			} catch (Exception e) {
				throw new BankException("problem in connection closing!!!!");
			}
		}
	}

	void putTransaction(double amount, long acc, String msg, double bal) throws BankException {

		try {
			con = ConnectionFactory.getSigtonObj().getConnection();
		} catch (BankException e) {
			// TODO Auto-generated catch block
			throw new BankException("connection couldn't be stablished!!!");
		}
		try {
			ps = con.prepareStatement(QueryMapping.INSERT_TRANSACTION);
			ps.setLong(1, acc);
			ps.setDouble(2, amount);
			ps.setString(3, msg);
			ps.setDate(4, Date.valueOf(java.time.LocalDate.now()));
			ps.setDouble(5, bal);

			ps.executeUpdate();
		} catch (Exception e) {
			throw new BankException("couldn't execute query!!!");
		} finally {
			try {
				if (con != null)
					con.close();
				if (ps != null)
					ps.close();
			} catch (Exception e) {
				throw new BankException("problem in connection closing!!!!");
			}
		}
	}

	@Override
	public boolean fundTransfer(long accNum, long accNum2, double ammount) throws BankException {
		// TODO Auto-generated method stub
		if(withdraw(accNum, ammount) && deposit(accNum2, ammount))
			return true;
		return false;
	}

	@Override
	public List<Transaction> printTransactions(long accNum) throws BankException {
		try {
			con = ConnectionFactory.getSigtonObj().getConnection();
		} catch (BankException e) {
			// TODO Auto-generated catch block
			throw new BankException("connection couldn't be stablished!!!");
		}
		try {
			ps = con.prepareStatement(QueryMapping.SELECT_TRANSACTION);
			ps.setLong(1, accNum);
			ResultSet rs = ps.executeQuery();
			List<Transaction> trainsactions = new ArrayList<Transaction>();
			while (rs.next()) {
				Transaction transaction = new Transaction();
				transaction.setDate(rs.getDate(4).toLocalDate());
				transaction.setAmmount(rs.getDouble(2));
				transaction.setType(rs.getString(3));
				transaction.setBalance(rs.getDouble(5));
				trainsactions.add(transaction);
			}
			System.out.println("------------------------------------------------");
			return trainsactions;
		} catch (Exception e) {
			throw new BankException("couldn't execute query!!!");
		} finally {
			try {
				if (con != null)
					con.close();
				if (ps != null)
					ps.close();
			} catch (Exception e) {
				throw new BankException("problem in connection closing!!!!");
			}
		}
	}

}
