package com.cg.bankapp.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.cg.bankapp.exception.BankException;
import com.cg.bankapp.persistance.AccountRepoImpl;
import com.cg.bankapp.persistance.IAccountRepo;

public class TestBal {

	IAccountRepo dao = new AccountRepoImpl(); 
	
	@Test(expected=BankException.class)
	public void test() throws BankException {
			assertEquals(0, dao.showBalance(12345), 1);
	}
	
	@Test
	public void test2() throws BankException {
			assertEquals(2000, dao.showBalance(1000), 1);
	}
}
