package com.cg.bankapp.bean;

public class Account {
	private static String bankName = "Bank";
	private String accHolder;
	private String address;
	private long acNum;
	private long mobNum;
	private double balance;
	private String email;
		
	public static String getBankName() {
		return bankName;
	}
	public static void setBankName(String bankName) {
		Account.bankName = bankName;
	}
	public String getAccHolder() {
		return accHolder;
	}
	public void setAccHolder(String accHolder) {
		this.accHolder = accHolder;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public long getAcNum() {
		return acNum;
	}
	public void setAcNum(long acNum) {
		this.acNum = acNum;
	}
	public long getMobNum() {
		return mobNum;
	}
	public void setMobNum(long mobNum) {
		this.mobNum = mobNum;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	@Override
	public String toString() {
		return "Account [accHolder=" + accHolder + ", address=" + address
				+ ", acNum=" + acNum + ", mobNum=" + mobNum + ", balance="
				+ balance + ", email=" + email + "]";
	}
	
}
