package com.cg.bankapp.test;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestMobVal {

	@Test
	public void test() {

	}

}
