package com.cg.bankapp.bean;

import java.time.LocalDate;

public class Transaction {
	private double ammount;
	private String type; // debit or credit
	private LocalDate date;
	private double balance;
	
	public double getAmmount() {
		return ammount;
	}
	public void setAmmount(double ammount) {
		this.ammount = ammount;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate localDate) {
		this.date = localDate;
	}
	
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	@Override
	public String toString() {
		return "Transaction [ammount=" + ammount + ", type=" + type + ", date="
				+ date + ", balance=" + balance + "]\n";
	}
	
}
