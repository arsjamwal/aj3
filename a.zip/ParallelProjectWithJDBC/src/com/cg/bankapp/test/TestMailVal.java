package com.cg.bankapp.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.cg.bankapp.service.AccountServiceImpl;
import com.cg.bankapp.service.IAccountService;

public class TestMailVal {

	IAccountService service = new AccountServiceImpl();
	
	@Test
	public void testRightMail() {
		String mail = "ars@gmail.com";
		assertTrue(service.mailValidation(mail));
	}
	
	@Test // start with number
	public void testRightMail2() {
		String mail = "12345@gmail.com";
		assertTrue(service.mailValidation(mail));
	}
	
	@Test // not minimum character before '@'
	public void testWrongMail() {
		String mail = "@gmail.com";
		assertFalse(service.mailValidation(mail));
	}
	
	@Test // no '@' 
	public void testWrongMail2() {
		String mail = "arsgmail.com";
		assertFalse(service.mailValidation(mail));
	}
	
	@Test // without (.) dot 
	public void testWrongMail3() {
		String mail = "a@gmailcom";
		assertFalse(service.mailValidation(mail));
	}
}
