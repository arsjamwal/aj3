package com.cg.bankapp.service;

import java.util.List;

import com.cg.bankapp.bean.Account;
import com.cg.bankapp.bean.Transaction;
import com.cg.bankapp.exception.BankException;

public interface IAccountService {
	long addAccount(Account a) throws BankException;
	double showBalance(long accNum) throws BankException;
	boolean deposit(long accNum, double ammount) throws BankException;
	boolean withdraw(long accNum, double ammount) throws BankException;
	boolean fundTransfer(long accNum, long accNum2, double ammount) throws BankException;
	List<Transaction> printTransactions(long accNum) throws BankException;
	boolean mailValidation (String mail);
	boolean mobValidation(long num);
	boolean accHolderValidation(String accHolder);
	boolean balanceValidation(double balance);
	boolean accNumValidation(long accNum);
}
