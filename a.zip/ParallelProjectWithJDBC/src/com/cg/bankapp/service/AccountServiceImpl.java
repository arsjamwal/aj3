package com.cg.bankapp.service;

import java.util.List;

import com.cg.bankapp.bean.Account;
import com.cg.bankapp.bean.Transaction;
import com.cg.bankapp.exception.BankException;
import com.cg.bankapp.persistance.AccountRepoImpl;
import com.cg.bankapp.persistance.IAccountRepo;

public class AccountServiceImpl implements IAccountService {
	
	IAccountRepo iap = new AccountRepoImpl();

	@Override
	public long addAccount(Account a) throws BankException{
		// TODO Auto-generated method stub
		try {
			return iap.addAccount(a);
		} catch (BankException e) {
			// TODO Auto-generated catch block
			throw new BankException(e.getMessage());
		}
	}

	@Override
	public double showBalance(long accNum) throws BankException {
		// TODO Auto-generated method stub
		return iap.showBalance(accNum);
	}

	@Override
	public boolean deposit(long accNum, double ammount) throws  BankException{
		// TODO Auto-generated method stub
		return iap.deposit(accNum, ammount);
	}

	@Override
	public boolean withdraw(long accNum, double ammount) throws BankException {
		// TODO Auto-generated method stub
		return iap.withdraw(accNum, ammount);
	}

	@Override
	public boolean fundTransfer(long accNum, long accNum2, double ammount) throws  BankException{
		// TODO Auto-generated method stub
		return iap.fundTransfer(accNum, accNum2, ammount);
	}

	@Override
	public List<Transaction> printTransactions(long accNum) throws  BankException{
		// TODO Auto-generated method stub
		return iap.printTransactions(accNum);
	}
	
	@Override
	public boolean mailValidation (String mail){
		String regex = "[a-zA-Z0-9]+[@][a-zA-Z0-9]+([.][a-zA-Z]+)+";
		return mail.matches(regex);
	}
	
	@Override
	public boolean mobValidation(long num){
		String regex = "(91|0)?[6-9][0-9]{9}";
		String sNum = Long.toString(num);
		return sNum.matches(regex);
	}
	
	@Override
	public boolean accHolderValidation(String accHolder) {
		String regex = "[A-Z][a-z]{3,15}";
		if(accHolder == null)
			return false;
		
		return accHolder.matches(regex);
	}
	
	@Override
	public boolean balanceValidation(double balance) {
		String regex = "[0-9]*\\.?[0-9]*";
		String bal = Double.toString(balance);
		//System.out.println(bal);
		return bal.matches(regex);
	}
	
	@Override
	public boolean accNumValidation(long num){
		String regex = "[0-9]{4,10}";
		String sNum = Long.toString(num);
		return sNum.matches(regex);
	}
	
}
