package com.cg.bankapp.exception;

public class BankException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public BankException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}

}
